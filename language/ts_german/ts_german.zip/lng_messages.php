<?php

$lng['message_profile_saved'] = 'Ihr Profil wurde erfolgreich gespeichert!';

$lng['message_no_forums'] = 'Bisher existieren keine Kategorien und/oder Foren!';

$lng['message_no_topics'] = 'In diesem Forum wurden bisher keine Themen erstellt!';

$lng['message_registration_successful'] = 'Sie wurden erfolgreich registriert!';

$lng['message_not_logged_in'] = 'Sie m&uuml;ssen eingeloggt sein um diese Funktion nutzen zu k&ouml;nnen!';

$lng['message_board_config_updated'] = 'Die Boardkonfiguration wurde erfolgreich geupdated!';

$lng['message_template_config_updated'] = 'Die Templatekonfiguration wurde erfolgreich geupdated!';

?>