<?php

$lng['Topics'] = 'Themen';
$lng['Topic'] = 'Thema';
$lng['Posts'] = 'Beitr&auml;ge';
$lng['Post'] = 'Beitrag';
$lng['Last_post'] = 'Neuester Beitrag';
$lng['Moderators'] = 'Moderatoren';
$lng['Forum'] = 'Forum';
$lng['Register'] = 'Registrieren';
$lng['Forumindex'] = 'Foren&uuml;bersicht';
$lng['Nick'] = 'Nick';
$lng['User_name'] = 'Benutzername';
$lng['Password'] = 'Passwort';
$lng['PW'] = 'PW';
$lng['Emailaddress'] = 'Emailadresse';
$lng['Error'] = 'Fehler';
$lng['Login'] = 'Einloggen';
$lng['Forum_message'] = 'Forum Meldung';
$lng['Replies'] = 'Antworten';
$lng['Views'] = 'Views';
$lng['Options'] = 'Optionen';
$lng['Preview'] = 'Vorschau';
$lng['Title'] = 'Titel';
$lng['Maximum_x_chars'] = 'Maximal %s Zeichen'; // %s = Anzahl der Zeichen
$lng['Author'] = 'Autor';
$lng['Guest'] = 'Gast';
$lng['Deleted_user'] = 'Ge&ouml;schter User';
$lng['Edit'] = 'bearbeiten';
$lng['Pages'] = 'Seiten %s'; // %s = Auflistung der Seiten
$lng['Reset'] = 'Zur&uuml;cksetzen';
$lng['Not_logged_in'] = 'Nicht eingeloggt';
$lng['Other_options'] = 'Weitere Optionen';
$lng['Yes'] = 'Ja';
$lng['No'] = 'Nein';


//
// forumindex.php
//
$lng['by'] = 'von';
$lng['No_last_post'] = '--Keine Beitr&auml;ge vorhanden--';
$lng['No_forums_cats'] = 'Keine Foren/Kategorien';
$lng['Mark_forums_read'] = 'Alle Foren als gelesen markieren';


//
// login.php
//
$lng['Logindata'] = 'Logindaten';
$lng['Hide_from_who_is_online'] = 'Nicht in die &quot;Wer ist online?&quot;-Liste aufnehmen';


//
// register.php
//
$lng['nick_conventions'] = 'maximal 15 Zeichen; nur Zahlen, Buchstaben und Unterstriche erlaubt';
$lng['Confirm_Password'] = 'Passwort Wiederholung';
$lng['Location'] = 'Wohnort';
$lng['Homepage'] = 'Homepage';
$lng['Interests'] = 'Hobbies';
$lng['Signature'] = 'Signatur';
$lng['ICQ'] = 'ICQ Nummer';
$lng['Homepage'] = 'Homepage';
$lng['Real_name'] = 'Echter Name';
$lng['Required_information'] = 'Ben&ouml;tigte Angaben';
$lng['Other_information'] = 'Sonstige Angaben';
$lng['Yahoo'] = 'Yahoo Name';
$lng['AIM'] = 'AIM Name';
$lng['MSN'] = 'MSN Name';
$lng['Registration_successful'] = 'Erfolgreich registriert';
$lng['error_bad_nick'] = 'Bitte geben Sie einen g&uuml;ltigen Benutzernamen	 ein!';
$lng['error_bad_email'] = 'Bitte geben Sie eine g&uuml;ltige Emailadresse ein!';
$lng['error_no_pw'] = 'Bitte geben Sie ein Passwort ein!';
$lng['error_pws_no_match'] = 'Das Passwort und die Wiederholung stimmen nicht &uuml;berein!';
$lng['error_bad_icq'] = 'Bitte geben Sie eine g&uuml;ltige ICQ-Nummer ein!';
$lng['error_nick_already_in_use'] = 'Dieser Benutzername wird schon von einem anderen User verwendet!';


//
// viewforum.php
//
$lng['No_topics'] = '--Bisher wurden keine Themen erstellt!--';
$lng['Mark_topics_read'] = 'Alle Themen als gelesen markieren';
$lng['Post_new_topic'] = 'Neues Thema erstellen';
$lng['Topic_poster'] = 'Themenersteller';
$lng['Important'] = 'Wichtig';
$lng['Moved'] = 'Verschoben';


//
// viewtopic.php
//
$lng['Posted'] = 'Geposted';
$lng['Quote'] = 'Zitat';
$lng['Post_new_reply'] = 'Neue Antwort erstellen';
$lng['Move_topic'] = 'Thema verschieben';
$lng['Delete_topic'] = 'Thema l&ouml;schen';
$lng['Mark_topic_important'] = 'Thema als wichtig markieren';
$lng['Mark_topic_unimportant'] = 'Thema als unwichtig markieren';


//
// posttopic.php
//
$lng['Post_topic'] = 'Thema erstellen';
$lng['Enable_smilies'] = 'Smilies aktivieren?';
$lng['Enable_bbcode'] = 'BBCode aktivieren?';
$lng['Enable_html_code'] = 'HTML-Code aktivieren?';
$lng['Show_signature'] = 'Signatur unter diesem Beitrag anzeigen?';
$lng['error_no_title'] = 'Bitte geben Sie einen Titel ein!';
$lng['error_title_too_long'] = 'Der Titel ist zu lange!';
$lng['error_no_post'] = 'Bitte geben Sie einen Beitrag ein!';
$lng['Your_name'] = 'Ihr Name';


//
// postreply.php
//
$lng['Post_reply'] = 'Antwort erstellen';
$lng['Topic_review'] = 'Neueste Antworten';


//
// pheader.php
//
$lng['My_profile'] = 'Mein Profil';
$lng['Logout'] = 'Ausloggen';
$lng['Logout_nick'] = 'Ausloggen [ %s ]';
$lng['welcome_not_logged_in'] = "<b>Willkommen bei %s!</b> Falls dies Ihr erster Besuch hier ist, lesen Sie sich bitte das <a href=\"index.php?faction=viewfaq&amp;$MYSID\">F.A.Q. mit den h&auml;ufigsten Fragen</a> durch! Falls Sie an den Diskussionen teilnehmen wollen, sollten Sie <a href=\"index.php?faction=register&amp;$MYSID\">sich registrieren</a> oder, falls Sie das schon getan haben, <a href=\"index.php?faction=login&amp;$MYSID\">sich einloggen</a>. Wir w&uuml;nschen Ihnen viel Spa&szlig;!"; // $s = Name des Boards
$lng['welcome_logged_in'] = 'Hallo %s! Wir haben '.format_time(time());

//
// ptail.php
//
$lng['db_queries'] = 'Datenbankzugriffe';
$lng['site_creation_time'] = 'Seitenaufbauzeit';


//
// edittopic.php
//
$lng['Edit_topic'] = 'Thema bearbeiten';


//
// editprofile.php
//
$lng['View_change_my_profile'] = 'Mein Profil ansehen/&auml;ndern';
$lng['Edit_profile'] = 'Profil bearbeiten';
$lng['General_information'] = 'Allgemeine Informationen';
$lng['Change_password'] = 'Passwort &auml;ndern';
$lng['New_password'] = 'Neues Passwort';
$lng['Confirm_new_password'] = 'Neues Passwort best&auml;tigen';
$lng['new_password_info'] = 'Wenn Sie das Passwort nicht &auml;ndern wollen, lassen Sie die folgenden Felder einfach leer.';
$lng['Profile_saved'] = 'Profil gespeichert';
$lng['Delete_account'] = 'Account l&ouml;schen';


//
// viewwio.php
//
$lng['Who_is_online'] = 'Wer ist online?';
$lng['wio_forumindex'] = 'Schaut sich gerade die Foren&uuml;bersicht an';
$lng['wio_viewwio'] = 'Schaut sich gerade die &quot;Wer ist online?&quot;-Liste an';
$lng['wio_viewforum'] = 'Schaut sich gerade ein Forum an';
$lng['wio_viewtopic'] = 'Schaut sich gerade ein Thema an';
$lng['wio_edittopic'] = 'Bearbeitet gerade ein Thema';
$lng['wio_editpost'] = 'Bearbeitet gerade einen Beitrag';
$lng['wio_postreply'] = 'Erstellt gerade eine Antwort';
$lng['wio_posttopic'] = 'Erstellt gerade ein Thema';
$lng['wio_login'] = 'Loggt sich gerade ein';
$lng['wio_logout'] = 'Loggt sich gerade aus';


//
// Die Links f�r die Nachrichten (lng_messages.php)
//
$lng['click_here_back_profile'] = '%sHier%s geht\'s zur&uuml;ck zum Profil'; // %s = Link
$lng['click_here_back_forumindex'] = '%sHier%s geht\'s zur&uuml;ck zur Foren&uuml;bersicht'; // %s = Link
$lng['click_here_login'] = '%sHier%s k&ouml;nnen Sie sich einloggen'; // %s = Link
$lng['click_here_register'] = '%sHier%s k&ouml;nnen Sie sich registrieren'; // %s = Link



?>